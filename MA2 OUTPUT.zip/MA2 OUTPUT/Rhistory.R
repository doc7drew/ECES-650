mbSet<-Init.mbSetObj()
mbSet<-SetModuleType(mbSet, "mdp")
mbSet<-ReadSampleTable(mbSet, "database_correctedJune25 1(BI form)-2.csv");
mbSet<-Read16STaxaTable(mbSet, "ASV_tax_species.silva_138_2.csv");
mbSet<-Read16SAbundData(mbSet, "ASV_table(Sheet 1 - ASV_table).csv","text","Others/Not_specific","T","false");
mbSet<-SanityCheckData(mbSet, "text","sample","true");
mbSet<-SanityCheckSampleData(mbSet);
mbSet<-SetMetaAttributes(mbSet, "1")
mbSet<-PlotLibSizeView(mbSet, "norm_libsizes_0","png");
mbSet<-CreatePhyloseqObj(mbSet, "text","Others/Not_specific","F" , "false")
